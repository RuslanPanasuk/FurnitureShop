
@@include('libs/lightgallery.min.js', {})